<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="br.com.restaurante.model.Usuario" %>
<%@ taglib prefix="c"   uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"  %>
<%--
    ================================================================
    DASHBOARD.JSP — PAINEL DO GERENTE (v4 — visual alinhado ao Figma)
    ================================================================
    Restilizado para usar os novos "stat-cards" com ícone colorido
    (classe .icon-box do style.css v4), no mesmo padrão visual do
    Painel do protótipo Figma.

    ⚠️ SOBRE OS DADOS — O QUE É REAL E O QUE O FIGMA MOSTRA A MAIS:
    O protótipo do Figma tem 4 cards (Mesas Livres, Pedidos Ativos,
    Faturamento Hoje, Ticket Médio) + um gráfico de linha "Receita da
    Semana". Só consegui manter esta página 100% HONESTA com o
    backend real usando exatamente os dados que o DashboardController
    já calcula e disponibiliza via request.setAttribute(...):
        totalMesas, mesasLivres, mesasOcupadas, mesasReservadas,
        pedidosAbertos, totalHoje, ultimosPedidos

    Não existe, hoje, nenhum atributo "ticketMedio" nem uma série de
    "receita por dia da semana" vindo do Controller — inventar esses
    números na JSP (ou fabricar um gráfico com valores fixos) deixaria
    a tela BONITA mas MENTIROSA, mostrando estatísticas que não vêm
    do banco de dados. Por isso:
      - Os 4 cards abaixo usam SÓ dados reais: Mesas Livres, Mesas
        Ocupadas, Pedidos em Aberto e Faturamento Hoje (era
        exatamente isso que a versão anterior já mostrava — só o
        visual mudou).
      - O gráfico "Receita da Semana" do Figma NÃO foi replicado
        aqui. Para fazer isso de verdade (com dados reais), seria
        necessário: 1) adicionar uma query no DashboardController
        somando o faturamento por dia dos últimos 7 dias, 2) expor
        esse resultado como um novo atributo (ex: "receitaPorDia",
        um Map<String,BigDecimal>), e só então desenhar o gráfico
        aqui (dá pra fazer com um <svg> simples usando <c:forEach>,
        sem precisar de biblioteca JS). Se você quiser, posso
        implementar essa parte no Controller depois — avisa que eu
        faço o resto (JSP + SQL) na sequência.
      - "Ticket Médio" também ficou de fora pelo mesmo motivo: não
        há, hoje, uma query separada de "pedidos de hoje" (só
        "pedidos em aberto", que é uma métrica diferente) para
        calcular esse valor com honestidade.
    ================================================================
--%>
<% Usuario _u=(Usuario)session.getAttribute("usuarioLogado"); %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Painel — Integrador</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<div class="main-container">
<%@ include file="/WEB-INF/views/shared/_sidebar.jsp" %>
<div class="main-content">
  <header class="topbar">
    <div class="topbar-left"><h2>Painel</h2></div>
    <div class="topbar-right">
      <div class="user-info">
        <div class="user-avatar"><%=_u.getNome().substring(0,1).toUpperCase()%></div>
        <div class="user-details">
          <span class="name"><%=_u.getNome()%></span>
          <span class="role">Gerente</span>
        </div>
      </div>
    </div>
  </header>
  <main class="content">
    <c:if test="${not empty erro}"><div class="alert alert-error">${erro}</div></c:if>

    <%-- Stat-cards com ícone colorido, um por métrica —
         mesma estrutura visual dos cards "Mesas Livres / Pedidos
         Ativos / Faturamento Hoje / Ticket Médio" do Figma, mas
         só com as métricas que o Controller realmente calcula
         (ver explicação completa no comentário do topo). --%>
    <div class="cards-grid">
      <div class="stat-card">
        <div class="icon-box verde">🪑</div>
        <div class="stat-label">Mesas Livres</div>
        <div class="stat-value">${mesasLivres}<span style="font-size:15px;color:var(--text-secondary)">/${totalMesas}</span></div>
        <div class="stat-context">de ${totalMesas} no total</div>
      </div>
      <div class="stat-card">
        <div class="icon-box vermelho">🔴</div>
        <div class="stat-label">Mesas Ocupadas</div>
        <div class="stat-value">${mesasOcupadas}</div>
      </div>
      <div class="stat-card">
        <div class="icon-box ambar">🧾</div>
        <div class="stat-label">Pedidos em Aberto</div>
        <div class="stat-value">${pedidosAbertos}</div>
        <div class="stat-context">em andamento agora</div>
      </div>
      <div class="stat-card">
        <div class="icon-box azul">💰</div>
        <div class="stat-label">Faturamento Hoje</div>
        <div class="stat-value" style="font-size:22px">
          R$ <fmt:formatNumber value="${totalHoje}" minFractionDigits="2" maxFractionDigits="2"/>
        </div>
        <div class="stat-context">desde a abertura</div>
      </div>
    </div>

    <div class="card mb-20">
      <h3>Ações Rápidas</h3>
      <div class="d-flex gap-10" style="flex-wrap:wrap">
        <a href="${pageContext.request.contextPath}/app/mesas"     class="btn btn-primary">🪑 Ver Mesas</a>
        <a href="${pageContext.request.contextPath}/app/pedidos"   class="btn btn-secondary">🧾 Pedidos</a>
        <a href="${pageContext.request.contextPath}/app/fila"      class="btn btn-secondary">👨‍🍳 Fila de Preparo</a>
        <a href="${pageContext.request.contextPath}/app/cardapio"  class="btn btn-secondary">📋 Cardápio</a>
        <a href="${pageContext.request.contextPath}/app/relatorios" class="btn btn-secondary">📄 Relatórios</a>
      </div>
    </div>

    <div class="card">
      <h3>Pedidos em Andamento</h3>
      <c:choose>
        <c:when test="${empty ultimosPedidos}">
          <div class="empty-state"><div class="icon">🎉</div><p>Nenhum pedido em aberto.</p></div>
        </c:when>
        <c:otherwise>
          <div class="table-wrapper">
            <table>
              <thead><tr><th>#</th><th>Tipo</th><th>Mesa</th><th>Operador</th><th>Status</th><th>Urgente</th><th>Abertura</th></tr></thead>
              <tbody>
                <c:forEach var="p" items="${ultimosPedidos}">
                  <tr>
                    <td><strong>#${p.idPedido}</strong></td>
                    <td><c:choose><c:when test="${p.tipo=='mesa'}">🪑 Mesa</c:when><c:otherwise>🛵 Delivery</c:otherwise></c:choose></td>
                    <td><c:choose><c:when test="${not empty p.mesa}">Mesa ${p.mesa.numero}</c:when><c:otherwise><span class="text-muted">—</span></c:otherwise></c:choose></td>
                    <td>${p.identificadorOperador}</td>
                    <td>
                      <c:choose>
                        <c:when test="${p.status=='aberto'}"><span class="badge badge-info">Recebido</span></c:when>
                        <c:when test="${p.status=='em_preparo'}"><span class="badge badge-warning">Em preparo</span></c:when>
                        <c:when test="${p.status=='pronto'}"><span class="badge badge-success">Pronto</span></c:when>
                        <c:otherwise><span class="badge">${p.status}</span></c:otherwise>
                      </c:choose>
                    </td>
                    <td><c:if test="${p.urgente}"><span class="badge badge-urgente">Urgente</span></c:if><c:if test="${!p.urgente}"><span class="text-muted">Normal</span></c:if></td>
                    <td class="text-muted">${p.dataAberturaFormatada}</td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </div>
          <c:if test="${pedidosAbertos > 8}">
            <div class="text-center mt-10">
              <a href="${pageContext.request.contextPath}/app/pedidos" class="btn btn-secondary btn-sm">Ver todos os ${pedidosAbertos} pedidos</a>
            </div>
          </c:if>
        </c:otherwise>
      </c:choose>
    </div>
  </main>
</div>
</div>
</body></html>
